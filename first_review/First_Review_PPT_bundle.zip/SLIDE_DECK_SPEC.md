# Slide Deck Spec — First Review

Build target: a **20-slide, 4:3 (10×7.5")** PowerPoint for a college "Project Work Phase I — First
Review." Content, layout, exact text, the image to place, and a one-line narration are given per slide.
All images are in `assets/`. Read `README_FOR_CLAUDE.md` first for build rules.

## Design system (apply to every slide)
- **Palette:** Navy `#1F3764` (primary / titles / BTYD) · Teal `#2A9D8F` (structural / GGG) ·
  Amber `#E9A13B` (machine learning) · Slate `#5B6B8C` · Purple `#7B5EA7` (ZILN) · Green `#4C9F70`
  (conformal) · Ink `#22252A` (body text) · background white.
- **Type:** one sans family (Calibri/Arial/Inter). Title 26–30 pt bold navy; body 16–20 pt ink;
  table 11–12 pt. Never below 11 pt.
- **Every content slide:** short title bar in navy; footer "First Review" + slide number; keep ≤5
  bullets, ≤2 lines each. The images already carry the palette — don't recolor them.
- **Slides that are an image:** give the image ~70–80% of the area, 2–3 bullets above it.

## Rubric being scored (50) — build to it
Clarity 7 · Problem & Objective 7 · Literature (5+ sources) 7 · Methodology/Planning 7 ·
**Dataset + Preprocessing + Initial Implementation 15** · Viva 7. Slides 10 + 12–15 must visibly show
a working pipeline and real results (the 15-mark item).

---

## Slide 1 — Title
- **Layout:** Title slide with a college header band (institution name, "An Autonomous Institution",
  address, "Department of CSE (Artificial Intelligence & Machine Learning)").
- **Title:** Non-Contractual Churn: Are Customer-Purchase Forecasts Calibrated?
- **Subtitle:** A Statistical vs. Machine-Learned Benchmark
- **Body:** Student Members — **B. A. Pranava** (Reg. No. `____`) · **Vyasa R. Rajesawaran** (Reg. No. `____`).  Supervisor — Name `____`, Designation `____`.  Subject: 231ALP711P · Date `____`.
- **Visual:** none (header band only).
- **Notes:** "We ask whether the forecasts used to predict customer churn are actually trustworthy — not just accurate."

## Slide 2 — Introduction
- **Layout:** Title + 4 bullets (left) — optionally a small icon per bullet.
- **Body:**
  - In non-contractual settings (retail, e-commerce, groceries) customers **churn silently** — they stop buying, with no cancellation to observe.
  - "Buy-Till-You-Die" (BTYD) models — **Pareto/NBD** — infer from purchase history whether a customer is still "alive."
  - These forecasts drive **CLV, targeting and retention-budget** decisions.
  - **Problem:** models are trusted for point predictions — but is the *uncertainty* they report trustworthy, and do ML models do better?
- **Visual:** native (optional): a simple timeline of a customer — several purchase ticks, then a gap, with a "?" (alive or churned?).
- **Notes:** "You never see a customer quit; you infer it — the question is how much to trust that inference."

## Slide 3 — Objective
- **Layout:** Title + **four cards** (2×2), one per objective, each in a palette color.
- **Body:**
  - **O1** — Evaluate whether Pareto/NBD forecasts are **calibrated**, not just accurate (CRPS · PIT · coverage).
  - **O2** — Benchmark statistical **BTYD vs machine-learning** across counts, value, churn, timing.
  - **O3** — **Diagnose** where and why calibration breaks.
  - **O4** — Propose and validate **repairs** (conformal recalibration; Pareto/GGG).
- **Visual:** native four-card grid (colors: O1 navy, O2 amber, O3 slate, O4 teal).
- **Notes:** "Measure calibration, compare the two families, find the failure, fix it."

## Slide 4 — Literature Survey (1/3)
- **Layout:** Title + 5-column table, header + 3 rows. Columns: **YEAR · AUTHORS · TITLE · METHODOLOGY · OUTCOME (Adv./Disadv.)**.
- **Rows:**
  - 1987 · Schmittlein, Morrison & Colombo · Counting Your Customers · Pareto/NBD stochastic "alive?" model · Foundational CBA model; point-error evaluation only
  - 2005 · Fader, Hardie & Lee · Counting Your Customers the Easy Way · BG/NBD (geometric dropout) · Tractable, widely used; no calibration check
  - 2016 · Platzer & Reutterer · Ticking Away the Moments · Pareto/GGG (Gamma timing) · Better timing when buying is regular; still point-error
- **Notes:** "The stochastic BTYD lineage — powerful, but judged on point error."

## Slide 5 — Literature Survey (2/3)
- **Layout:** same table format.
- **Rows:**
  - 2019 · Wang, Liu & Miao · A Deep Probabilistic Model for CLV · Zero-inflated lognormal (ZILN) net · Predicts value distribution; assessed on accuracy, not calibration
  - 2022 · Valendin et al. · Customer Base Analysis with RNNs · Recurrent neural network · ML gains over BTYD on point error; calibration unexamined
  - 2025 · Simon · Generalised comparison of Pareto/NBD forecasts · MCMC vs MLE vs heuristics · Motivates us; compares only point error, calls timing "too inaccurate"
- **Notes:** "The ML side — accuracy gains, but again no calibration."

## Slide 6 — Literature Survey (3/3)
- **Layout:** same table format.
- **Rows:**
  - 2005 · Buckinx & Van den Poel · Partial defection in non-contractual FMCG · Logistic / NN / random forests · Canonical churn classifier; accuracy/AUC, no calibration
  - 2024 · De Caigny, De Bock & Verboven · Hybrid black-box churn prediction · Ensemble + SHAP · Recent ML churn; point classification
  - 2025 · Imani et al. · Customer Churn Prediction: A Systematic Review · Survey of ML/DL churn · Maps the field; confirms calibration is not evaluated
- **Notes:** "Even the newest churn work and the 2025 survey confirm the gap."

## Slide 7 — Summary of Literature (the gap)
- **Layout:** Title + 3 short bullets (top) + full-width image.
- **Body:**
  - BTYD dominates non-contractual CBA but is judged almost only on **point error**.
  - ML/DL churn & CLV models report accuracy gains — but **never test calibration**.
  - **Gap → our niche:** compare BTYD vs ML **by calibration** — the cell nobody occupies.
- **Visual:** `assets/infographic_positioning.png`
- **Notes:** "That empty cell — calibration × customer forecasting — is exactly where we sit."

## Slide 8 — Architecture of the Proposed Method
- **Layout:** Title + full-width image.
- **Visual:** `assets/infographic_architecture.png`
- **Notes:** "Both model families run one pipeline; we score their full predictive distributions, then repair them."

## Slide 9 — Proposed System (methodology & core hypothesis)
- **Layout:** Title + 3 bullets (left ~40%) + image (right ~60%).
- **Body:**
  - **The calibration lens** — score the whole distribution: CRPS (sharpness), PIT (uniform if calibrated), coverage (95% ⇒ 95%).
  - **Four dimensions:** counts · value · churn · timing.
  - **Hypothesis:** one shared *parametric count assumption* governs calibration — not the estimator, not the variant.
- **Visual:** `assets/infographic_thesis_hub.png`
- **Notes:** "One idea unifies the paper: calibration is set by the count assumption."

## Slide 10 — Datasets & Initial Implementation ⭐ (drives the 15-mark item)
- **Layout:** Title + image (top) + 3 compact blocks (below).
- **Visual:** `assets/infographic_dataset_spectrum.png`
- **Body:**
  - **Preprocessing:** raw event logs → per-customer RFM summary; calibration/hold-out split by rolling cut-point.
  - **Implemented (Python):** Pareto/NBD & BG/NBD (MLE + MCMC + amortized neural), Pareto/GGG; GBM + deep ZILN; conformal recalibration; CRPS/PIT/coverage engine.
  - **Status:** full pipeline running; multi-seed results across all four dimensions →
- **Notes:** "This is built and producing results on seven real datasets — not a proposal on paper."

## Slide 11 — Novelty
- **Layout:** Title + 4 bullets, each with a check-badge.
- **Body:**
  - **First** to compare BTYD vs ML by **calibration** (not point error), across all four dimensions.
  - A single diagnosis: the **count assumption** governs calibration.
  - Two validated repairs: **conformal** (model-agnostic) + **Pareto/GGG** (structural).
  - Invariance: MLE ≈ MCMC ≈ amortized; Pareto/NBD ≈ BG/NBD.
- **Visual:** native (check-badges); optional reuse of `assets/infographic_thesis_hub.png` small, corner.
- **Notes:** "The novelty is the evaluation lens and what it reveals, not the existence of the comparison."

## Slide 12 — Result & Discussion: Calibration map (counts)
- **Layout:** Title + 2 bullets (top) + image.
- **Body:**
  - Structure best on sparse data (PIT-KS **0.04**); breaks on dense (Online Retail II **0.21**, Dunnhumby **0.17**).
  - Distribution-free **Quantile-GBM wins exactly where BTYD breaks** (Dunnhumby 0.06). No universal winner.
- **Visual:** `assets/result_calibration_map.png`
- **Notes:** "The lens doesn't crown a model — it localises where each one's assumption fails."

## Slide 13 — Result & Discussion: Repair I (conformal)
- **Layout:** Title + 2 bullets (top) + image.
- **Body:**
  - One held-out recalibration restores calibration where broken, no harm where fine.
  - Online Retail II **0.212→0.044** · Ta-Feng **0.072→0.027** · Dunnhumby 0.164→0.097 (Grocery 0.036→0.036, unchanged).
- **Visual:** `assets/result_conformal.png`
- **Notes:** "A single cheap recalibration fixes the intervals without touching the model's fit."

## Slide 14 — Result & Discussion: Value & churn
- **Layout:** Title + 2 bullets (top) + image.
- **Body:**
  - Money: deep **ZILN better calibrated** than structural CLV where the count assumption fails (Online Retail II 0.212→0.031).
  - Churn P(active): calibrated on sparse, miscalibrated on dense; **RFM suffices — demographics add nothing**.
- **Visual:** `assets/result_clv.png`
- **Notes:** "The same assumption governs value and churn, not just counts."

## Slide 15 — Result & Discussion: Repair II (Pareto/GGG) & seasonality
- **Layout:** Title + 2 bullets (top) + image.
- **Body:**
  - Pareto/GGG cuts next-purchase median error where buying is regular (Grocery **3.89→2.98 weeks**) — rebuts "timing too inaccurate."
  - Seasonality: a structural term helps on controlled data (0.090→0.030); on real cohorts conformal alone suffices (0.082→0.021).
- **Visual:** `assets/result_timing.png`
- **Notes:** "Where a richer model matches the process, structure wins; otherwise recalibration is enough."

## Slide 16 — Action Plan (Aug → Oct 2026)
- **Layout:** Title + full-width image.
- **Visual:** `assets/infographic_timeline.png`
- **Notes:** "Three months: finish the review, harden the results, prepare for Phase II."

## Slide 17 — References (recent, 2023–2025)
- **Layout:** Title + numbered list, 14 pt.
- **Body:**
  1. Simon, L. (2025). A generalised comparison of Pareto/NBD based forecasts using MCMC, maximum likelihood, and heuristics. *Journal of Business Economics*, 95, 1079–1105.
  2. Imani, M., Joudaki, M., Beikmohammadi, A., & Arabnia, H. (2025). Customer Churn Prediction: A Systematic Review of Recent Advances, Trends, and Challenges in ML and DL. (MDPI).
  3. De Caigny, A., De Bock, K. W., & Verboven, S. (2024). Hybrid black-box classification for customer churn prediction with segmented interpretability analysis. *Decision Support Systems*.
  4. Boukrouh, I., & Azmani, A. (2025). Explainable machine learning models applied to predicting customer churn for e-commerce. *IAES IJ-AI*, 14(1), 286–297.

## Slide 18 — References (ML & CLV)
- **Layout:** Title + numbered list.
- **Body:**
  5. Valendin, J., Reutterer, T., Platzer, M., & Kalcher, K. (2022). Customer base analysis with recurrent neural networks. *IJRM*, 39(4), 988–1018.
  6. Wang, X., Liu, T., & Miao, J. (2019). A deep probabilistic model for customer lifetime value prediction. arXiv:1912.07753.
  7. Buckinx, W., & Van den Poel, D. (2005). Customer base analysis: partial defection… non-contractual FMCG retail setting. *EJOR*, 164(1), 252–268.
  8. Miguéis, V. L., Van den Poel, D., Camanho, A. S., & Falcão e Cunha, J. (2012). Modeling partial customer churn. *Expert Systems with Applications*, 39(12), 11250–11256.
  9. Chamberlain, B. P., et al. (2017). Customer lifetime value prediction using embeddings. *KDD*.

## Slide 19 — References (foundational BTYD + calibration)
- **Layout:** Title + numbered list.
- **Body:**
  10. Schmittlein, D. C., Morrison, D. G., & Colombo, R. (1987). Counting your customers… *Management Science*, 33(1), 1–24.
  11. Fader, P. S., Hardie, B. G. S., & Lee, K. L. (2005). "Counting your customers" the easy way. *Marketing Science*, 24(2), 275–284.
  12. Platzer, M., & Reutterer, T. (2016). Ticking away the moments. *Marketing Science*, 35(5), 779–799.
  13. Abe, M. (2009). Counting your customers one by one. *Marketing Science*, 28(3), 541–553.
  14. Gneiting, T., & Raftery, A. E. (2007). Strictly proper scoring rules, prediction, and estimation. *JASA*, 102(477), 359–378.
  15. Kuleshov, V., Fenner, N., & Ermon, S. (2018). Accurate uncertainties for deep learning using calibrated regression. *ICML*.

## Slide 20 — Thank You
- **Layout:** Centered "Thank You" + team names; optional college logo.
- **Notes:** one-line pitch — "We show popular churn forecasts are often mis-calibrated, find exactly why, and fix it two ways."

---
## Asset → slide map
| Slide | Asset |
|---|---|
| 7 | `assets/infographic_positioning.png` |
| 8 | `assets/infographic_architecture.png` |
| 9 | `assets/infographic_thesis_hub.png` |
| 10 | `assets/infographic_dataset_spectrum.png` |
| 12 | `assets/result_calibration_map.png` |
| 13 | `assets/result_conformal.png` |
| 14 | `assets/result_clv.png` |
| 15 | `assets/result_timing.png` |
| 16 | `assets/infographic_timeline.png` |

# Build instructions (read me first)

**Goal:** turn this bundle into a polished `.pptx` for a college "First Review" presentation.

## What's here
```
SLIDE_DECK_SPEC.md    ← the 20-slide spec: per-slide title, layout, exact text, image, and narration
README_FOR_CLAUDE.md  ← this file
assets/               ← all images, pre-themed (do not recolor)
    infographic_*.png     5 custom infographics  (slides 7, 8, 9, 10, 16)
    result_*.png          4 real result figures  (slides 12–15)
```

## How to build
1. **Read `SLIDE_DECK_SPEC.md` fully.** It is the source of truth — 20 slides, in order, each with a
   Layout, Title, Body (verbatim), Visual, and Notes.
2. **Format:** 4:3 (10×7.5 in). Apply the *Design system* section (palette hexes, fonts, footer +
   slide number on every content slide). Use `python-pptx`.
3. **Place images** exactly per the "Asset → slide map" at the end of the spec. For an image slide,
   give the image ~70–80% of the area and put the 2–3 body bullets above it. **Do not recolor the
   images** — they already carry the palette.
4. **Native-shape slides (2, 3, 11):** build these with PowerPoint shapes, not images — the spec says
   how (a customer timeline; a 2×2 objective-card grid; four check-badges). Colour them from the palette.
5. **Tables (slides 4–6):** 5 columns, header + 3 rows, 11–12 pt; header row in navy with white text.
6. **Put the Notes line into each slide's speaker-notes**, not on the slide.
7. **Keep text terse** — never paste a Body bullet longer than ~2 lines onto a slide; trim to fit.

## Placeholders to leave for the user (Slide 1)
Reg. Nos. (both students), Supervisor name & designation, and the Date — keep them as visible blanks
`____`; do not invent them.

## Quality bar
Every number on slides 12–15 is real (from the project's results) — keep them exact. Aim for a clean,
consistent, presentable deck that scores on: clarity, a 9-paper literature survey, a clear
methodology + architecture, a strong datasets/implementation slide (worth 15/50), and real results.
